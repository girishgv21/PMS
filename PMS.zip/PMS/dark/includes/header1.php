<html>
<body>

    <img id="logo" src="images/logo.png" width="40px">
    <nav>
      <ul>
        <a href="index.php" class="active" id="home"><li>Home</li></a>
        <a href="admin/login.php" id="admin"><li>Admin</li></a>
        <a href="student/login.php" id="student"><li>Student</li></a>
        <a href="student/login.php" class="btn" id="btn">SIGNIN</a>
      </ul>
    </nav>
	</body>
</html>
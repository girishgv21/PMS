<script>
    alert("Passwords not matching!");
</script>